import logging

import librosa
from transformers import pipeline

from config import MAX_DURATION_SECONDS, MIN_DURATION_SECONDS, MODEL_ID, TARGET_SR

logger = logging.getLogger("deepfake_voice_detection")

try:
    classifier = pipeline("audio-classification", model=MODEL_ID)
    logger.info("Loaded model %s", MODEL_ID)
except Exception:
    logger.exception("Failed to load model %s", MODEL_ID)
    raise


class PredictionError(Exception):
    """Raised when an audio clip can't be scored; message is safe to show to users."""


def predict(audio_path):
    if audio_path is None:
        return None

    try:
        audio, _ = librosa.load(audio_path, sr=TARGET_SR, mono=True)
    except Exception:
        logger.exception("Failed to decode audio file: %s", audio_path)
        raise PredictionError(
            "Couldn't read that audio file. Try a different format (WAV, MP3, FLAC)."
        )

    duration = len(audio) / TARGET_SR
    if duration < MIN_DURATION_SECONDS:
        raise PredictionError("That clip is too short to analyze. Try a longer recording.")
    if duration > MAX_DURATION_SECONDS:
        raise PredictionError(
            f"That clip is too long ({duration:.0f}s). Please upload a clip under "
            f"{MAX_DURATION_SECONDS} seconds."
        )

    try:
        scores = classifier({"array": audio, "sampling_rate": TARGET_SR})
    except Exception:
        logger.exception("Model inference failed for: %s", audio_path)
        raise PredictionError("Something went wrong analyzing that clip. Please try again.")

    result = {item["label"]: float(item["score"]) for item in scores}
    logger.info("Prediction for %s: %s", audio_path, result)
    return result
