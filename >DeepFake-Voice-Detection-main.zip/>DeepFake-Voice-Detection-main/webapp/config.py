import os

MODEL_ID = "MelodyMachine/Deepfake-audio-detection-V2"
TARGET_SR = 16000

MIN_DURATION_SECONDS = 0.3
MAX_DURATION_SECONDS = 60

SERVER_NAME = os.environ.get("SERVER_NAME", "127.0.0.1")
SERVER_PORT = int(os.environ.get("PORT", "7860"))

DISCLAIMER_TEXT = (
    "This tool uses an experimental, off-the-shelf classifier. It has not been "
    "validated on real-world recordings and can be confidently wrong, especially "
    "outside typical clean speech audio. Do not rely on it for legal, financial, "
    "or other high-stakes decisions."
)
