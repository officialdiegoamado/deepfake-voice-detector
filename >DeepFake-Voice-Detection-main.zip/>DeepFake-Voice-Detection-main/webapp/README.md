# DeepFake Voice Detection — Web App

A Gradio web app for checking whether a voice recording is real human speech or AI-generated audio. Upload a clip or record from the microphone and get a real/fake verdict with a confidence breakdown.

> ⚠️ **Accuracy disclaimer:** this app uses an experimental, off-the-shelf classifier (`MelodyMachine/Deepfake-audio-detection-V2` from Hugging Face). It has not been validated on real-world recordings and can be confidently wrong, especially on audio outside typical clean speech (background noise, music, non-speech tones, unusual recording conditions). Do not rely on it for legal, financial, or other high-stakes decisions.

## Run locally

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

The app starts at `http://127.0.0.1:7860` by default. Override the port with the `PORT` env var, and the bind address with `SERVER_NAME` (e.g. `SERVER_NAME=0.0.0.0` for containers).

## Run with Docker

```bash
docker build -t deepfake-voice-detection .
docker run -p 7860:7860 deepfake-voice-detection
```

## Tests

```bash
pip install -r requirements-dev.txt
pytest tests/
```

## Project layout

- `app.py` — Gradio UI (layout, styling, disclaimer banner)
- `model.py` — model loading, inference, and input validation
- `config.py` — constants (model id, sample rate, duration limits, server settings)
- `tests/` — pytest suite covering the prediction/validation logic

## Live deployment

Deployed on Hugging Face Spaces: _link added once deployed_.
