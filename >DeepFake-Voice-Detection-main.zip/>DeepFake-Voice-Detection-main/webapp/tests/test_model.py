import numpy as np
import pytest
import soundfile as sf

from config import MAX_DURATION_SECONDS, TARGET_SR
from model import PredictionError, predict


def _write_tone(path, duration_seconds, sr=TARGET_SR, freq=220.0):
    t = np.linspace(0, duration_seconds, int(sr * duration_seconds), endpoint=False)
    tone = 0.1 * np.sin(2 * np.pi * freq * t).astype(np.float32)
    sf.write(path, tone, sr)


def test_predict_none_returns_none():
    assert predict(None) is None


def test_predict_valid_clip_returns_scores(tmp_path):
    wav_path = tmp_path / "tone.wav"
    _write_tone(wav_path, duration_seconds=2.0)

    result = predict(str(wav_path))

    assert set(result.keys()) == {"real", "fake"}
    assert pytest.approx(sum(result.values()), abs=1e-3) == 1.0


def test_predict_too_short_raises(tmp_path):
    wav_path = tmp_path / "short.wav"
    _write_tone(wav_path, duration_seconds=0.05)

    with pytest.raises(PredictionError):
        predict(str(wav_path))


def test_predict_too_long_raises(tmp_path):
    wav_path = tmp_path / "long.wav"
    _write_tone(wav_path, duration_seconds=MAX_DURATION_SECONDS + 5)

    with pytest.raises(PredictionError):
        predict(str(wav_path))
