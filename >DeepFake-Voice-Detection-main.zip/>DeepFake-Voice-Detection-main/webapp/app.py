import logging

import gradio as gr

from config import DISCLAIMER_TEXT, SERVER_NAME, SERVER_PORT
from model import PredictionError, predict

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def run_prediction(audio_path):
    if audio_path is None:
        return {}, gr.update(value="", visible=False)

    try:
        result = predict(audio_path)
    except PredictionError as exc:
        error_html = f"""
        <div class="verdict-banner verdict-error">
            <span class="verdict-icon">⚠️</span>
            <div>
                <div class="verdict-headline">Couldn't analyze this clip</div>
                <div class="verdict-sub">{exc}</div>
            </div>
        </div>
        """
        return {}, gr.update(value=error_html, visible=True)

    top_label = max(result, key=result.get)
    top_score = result[top_label]
    is_fake = "fake" in top_label.lower() or "spoof" in top_label.lower()

    verdict_class = "verdict-fake" if is_fake else "verdict-real"
    icon = "🚨" if is_fake else "✅"
    headline = "Likely AI-Generated" if is_fake else "Likely Real Voice"

    banner_html = f"""
    <div class="verdict-banner {verdict_class}">
        <span class="verdict-icon">{icon}</span>
        <div>
            <div class="verdict-headline">{headline}</div>
            <div class="verdict-sub">{top_score * 100:.1f}% confidence</div>
        </div>
    </div>
    """
    return result, gr.update(value=banner_html, visible=True)


CUSTOM_CSS = """
:root {
    --card-radius: 18px;
}

.gradio-container {
    max-width: 880px !important;
    margin: 0 auto !important;
}

#hero {
    text-align: center;
    padding: 2.2rem 1rem 1.4rem 1rem;
}

#hero h1 {
    font-size: 2.3rem;
    font-weight: 800;
    margin: 0;
    background: linear-gradient(90deg, #7c3aed, #db2777);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

#hero p {
    margin-top: 0.5rem;
    font-size: 1.02rem;
    opacity: 0.75;
}

#disclaimer {
    display: flex;
    align-items: flex-start;
    gap: 0.7rem;
    padding: 0.85rem 1.1rem;
    border-radius: 12px;
    margin: 0 0 1.2rem 0;
    background: rgba(245, 158, 11, 0.12);
    border: 1px solid rgba(245, 158, 11, 0.4);
    font-size: 0.88rem;
    line-height: 1.4;
}

.panel-card {
    border-radius: var(--card-radius) !important;
    padding: 1.2rem !important;
    box-shadow: 0 4px 18px rgba(0,0,0,0.06);
}

.verdict-banner {
    display: flex;
    align-items: center;
    gap: 0.9rem;
    padding: 1rem 1.2rem;
    border-radius: 14px;
    margin-bottom: 0.9rem;
    animation: fadeIn 0.35s ease-in;
}

.verdict-icon {
    font-size: 2rem;
}

.verdict-headline {
    font-size: 1.15rem;
    font-weight: 700;
}

.verdict-sub {
    font-size: 0.9rem;
    opacity: 0.75;
}

.verdict-real {
    background: rgba(16, 185, 129, 0.12);
    border: 1px solid rgba(16, 185, 129, 0.35);
}

.verdict-fake {
    background: rgba(239, 68, 68, 0.12);
    border: 1px solid rgba(239, 68, 68, 0.35);
}

.verdict-error {
    background: rgba(245, 158, 11, 0.12);
    border: 1px solid rgba(245, 158, 11, 0.4);
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-4px); }
    to { opacity: 1; transform: translateY(0); }
}

footer { display: none !important; }
"""

theme = gr.themes.Soft(
    primary_hue="violet",
    secondary_hue="pink",
    neutral_hue="slate",
    font=[gr.themes.GoogleFont("Inter"), "ui-sans-serif", "system-ui", "sans-serif"],
)

with gr.Blocks(title="DeepFake Voice Detection") as demo:
    gr.HTML(
        """
        <div id="hero">
            <h1>🎙️ DeepFake Voice Detection</h1>
            <p>Upload or record a voice clip to check whether it's real human speech or AI-generated audio.</p>
        </div>
        """
    )

    gr.HTML(f'<div id="disclaimer">⚠️&nbsp; {DISCLAIMER_TEXT}</div>')

    with gr.Row():
        with gr.Column(elem_classes="panel-card"):
            audio_input = gr.Audio(
                sources=["upload", "microphone"],
                type="filepath",
                label="Voice recording",
            )
            submit_btn = gr.Button("Analyze Voice", variant="primary", size="lg")

        with gr.Column(elem_classes="panel-card"):
            verdict = gr.HTML(visible=False)
            label_output = gr.Label(num_top_classes=2, label="Confidence breakdown")

    submit_btn.click(fn=run_prediction, inputs=audio_input, outputs=[label_output, verdict])
    audio_input.change(fn=lambda: (gr.update(), gr.update(visible=False)), outputs=[label_output, verdict])

demo.queue()

if __name__ == "__main__":
    demo.launch(
        server_name=SERVER_NAME,
        server_port=SERVER_PORT,
        theme=theme,
        css=CUSTOM_CSS,
    )
